<?php 
if($paciente!="no data"){
	echo json_encode($paciente);	
}else{
	print("no");	
}

 ?>