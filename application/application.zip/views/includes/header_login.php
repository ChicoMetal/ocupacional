<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Unicorn Admin</title>
		<meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="<?php echo base_url() ?>css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo base_url() ?>css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="<?php echo base_url() ?>css/unicorn.login.css" />
        <script src="<?php echo base_url() ?>js/jquery.min.js"></script>  
        <script src="<?php echo base_url() ?>js/unicorn.login.js"></script> 
        
	</head>
	<body



