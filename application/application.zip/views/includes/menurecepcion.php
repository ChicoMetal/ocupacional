<div id="sidebar">
            <a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
            <ul>
                <li class="active">
                    <a href="<?php echo base_url() ?>index.php/recepcion"><i class="icon icon-home"></i> <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="active">
                    <a href="<?php echo base_url() ?>index.php/citas/calendario"><i class="icon icon-home"></i> <span>Citas</span>
                    </a>
                </li>

            </ul>
        
        </div>
  <div id="content">      

<div id="content-header">
    <h1>Dashboard</h1>
    <div class="btn-group">
        <a class="btn btn-large tip-bottom" title="Manage Files"><i class="icon-file"></i></a>
        <a class="btn btn-large tip-bottom" title="Manage Users"><i class="icon-user"></i></a>
        <a class="btn btn-large tip-bottom" title="Manage Comments"><i class="icon-comment"></i><span class="label label-important">5</span></a>
        <a class="btn btn-large tip-bottom" title="Manage Orders"><i class="icon-shopping-cart"></i></a>
    </div>
</div>

<!--
 <img src="<?php echo base_url().$ses['usr_avatar']; ?>" alt="" class="span12 thumbnail">
        
            <h6><?php echo $ses['usr_nombre']; ?></h6>
-->    