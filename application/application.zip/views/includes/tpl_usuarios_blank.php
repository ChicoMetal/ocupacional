<?php

$this->load->view($contenido_principal);

?>
