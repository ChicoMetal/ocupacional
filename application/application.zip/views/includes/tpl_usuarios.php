<?php


$this->load->view('includes/header');
$this->load->view('includes/menuus');
//$this->load->view($menu);
$this->load->view($contenido_principal);
$this->load->view('includes/footer');

?>
