<?php
	$this->load->view('includes/headerdoctor');
	$this->load->view('includes/menudoctor');
	//$this->load->view($menu);
	$this->load->view($contenido_principal);
	$this->load->view('includes/footer');

?>
