<ul id="menu">
    <li><?php echo anchor('administrador/index','Inicio') ?></li>
    <li></li>
    <li></li>
   <li> <?php echo anchor('usuarios/logout','Salir') ?>  </li>
</ul>

