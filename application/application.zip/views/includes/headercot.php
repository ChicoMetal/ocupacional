<!DOCTYPE html>
<!--cot-->
<html lang="es-ES">
<head>

<title>C-<?php echo $titulo  ?></title>

 <?php //$this->output->set_header('Content-Type: text/html; charset=utf-8');?>
<link type="text/css" href="<?php echo base_url() ?>css/jquery-ui-1.8.12.custom/css/redmond/jquery-ui-1.8.12.custom.css" rel="Stylesheet" />
  <link type="text/css" href="<?php echo base_url() ?>css/validationEngine.jquery.css" rel="Stylesheet" />
 <!-- <link type="text/css" href="<?php echo base_url() ?>css/960.css">
  <link type="text/css" href="<?php echo base_url() ?>css/reset.css">
  <link type="text/css" href="<?php echo base_url() ?>css/text.css">-->
  <link type="text/css" href="<?php echo base_url() ?>css/estilocot.css" rel="Stylesheet" >
  <link rel="stylesheet" href="<?php echo base_url() ?>js/calendario/kalendar.css" type="text/css" media="screen" />


  <script type="text/javascript" src="<?php echo base_url() ?>js/jQuery.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/task.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/scrollToTop.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/calendario/jquery.kalendar.min.js" language="javascript" ></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/jquery-ui-1.8.1.custom.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/jquery.validate.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/jquery.validationEngine-es.js"  charset="utf-8"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/jquery.validationEngine.js"  charset="utf-8"> </script>
  <script type="text/javascript" src="<?php echo base_url() ?>js/qtip/jquery.qtip-1.0.0-rc3.min.js"  charset="utf-8"> </script>




</head>
<body>


