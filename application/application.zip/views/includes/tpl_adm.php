<?php


$this->load->view('includes/header');
$this->load->view('includes/menuadm');
//$this->load->view($menu);
$this->load->view($contenido_principal);
$this->load->view('includes/footer');

?>
