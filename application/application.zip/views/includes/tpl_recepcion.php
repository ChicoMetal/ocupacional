<?php
	$this->load->view('includes/headerecepcion');
	$this->load->view('includes/menurecepcion');
	//$this->load->view($menu);
	$this->load->view($contenido_principal);
	$this->load->view('includes/footer');

?>
