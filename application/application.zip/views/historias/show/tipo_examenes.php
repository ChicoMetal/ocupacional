
Tipo de examen

<?php 
$primero=0;

foreach ($data as  $datos) {

?>

 <?php echo $datos['nombre'] ?>
  
<?php

}

?>


