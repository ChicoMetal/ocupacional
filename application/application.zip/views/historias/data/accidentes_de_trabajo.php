<script>
$(document).ready(function() {
  $("#fechaaccidente").datepicker({
    changeMonth: true,
    changeYear: true,
    yearRange: "1900:2020",
    dateFormat: "yy/mm/dd",
  });
   $("#fechaaccidente1").datepicker({
    changeMonth: true,
    changeYear: true,
    yearRange: "1900:2020",
    dateFormat: "yy/mm/dd",
  });
});
</script>

  

  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Accidentes de trabajo</label>
      <div class="controls">
        <input type="text" value="niega"name="accidentes" id="accidentes">
        <input type="text" value="niega"name="accidentes1" id="accidentes1">
      </div>
    </div>
  </div>


   <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Enfermedad profesional</label>
      <div class="controls">
        <input type="text" value="niega"name="enfermedad" id="enfermedad">
        <input type="text" value="niega"name="enfermedad1" id="enfermedad1">
      </div>
    </div>
  </div>


  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Fecha</label>
      <div class="controls">
        <input type="text" value="niega"name="fechaaccidente" id="fechaaccidente" value="" placeholder="">
        <input type="text" value="niega"name="fechaaccidente1" id="fechaaccidente1" value="" placeholder="">
      </div>
    </div>
  </div>


  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Empresa</label>
      <div class="controls">
       <input type="text" value="niega"name="empresaaccidente" id="empresaaccidente">
       <input type="text" value="niega"name="empresaaccidente1" id="empresaaccidente1">
      </div>
    </div>
  </div>

  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Tipo de lesion</label>
      <div class="controls">
       <input type="text" value="niega"name="tipodelesion" id="tipodelesion">
       <input type="text" value="niega"name="tipodelesion1" id="tipodelesion1">
      </div>
    </div>
  </div>

  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Sitio de lesion</label>
      <div class="controls">
       <input type="text" value="niega"name="sitiodelesion" id="sitiodelesion">
       <input type="text" value="niega"name="sitiodelesion1" id="sitiodelesion1">
      </div>
    </div>
  </div>


  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Incapacidad</label>
      <div class="controls">
       <input type="text" value="niega"name="incapacidad" id="incapacidad">
       <input type="text" value="niega"name="incapacidad1" id="incapacidad1">
      </div>
    </div>
  </div>


  <div class="span12">
   
    <div class="control-group">
      <label for="textfield" class="control-label">Secuelas</label>
      <div class="controls">
       <input type="text" value="niega"name="secuelas" id="secuelas">
       <input type="text" value="niega"name="secuelas1" id="secuelas1">
      </div>
    </div>
  </div>


