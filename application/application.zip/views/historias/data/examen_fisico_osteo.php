
<div class="span6">
  <table  class="table table-hover table-nomargin table-bordered">
    
    <tbody>
      <tr>
        <th colspan="2" rowspan="2">TEST ORTOPÉDICOS</th>
        <th colspan="2">Derecho</th>
        <th colspan="2">Izquierdo</th>
      </tr>
      <tr>  
        <td>(+)</td>
        <td>(-)</td>
        <td>(+)</td>
        <td>(-)</td>

      </tr>
      <tr>
        <td rowspan="4">Miembro Superior</td>
        <td>PRUEBA EPICONDILITIS</td>
        <td><input type="radio" name="epicondilitisd" value="+"></td>
        <td><input type="radio" name="epicondilitisd" value="-"></td>
        <td><input type="radio" name="epicondilitisi" value="+"></td>
        <td><input type="radio" name="epicondilitisi" value="-"></td>
      </tr>
      <tr>
        
        <td>FINKELSTEIN</td>
        <td><input type="radio" name="finkelsteind" value="+"></td>
        <td><input type="radio" name="finkelsteind" value="-"></td>
        <td><input type="radio" name="finkelsteini" value="+"></td>
        <td><input type="radio" name="finkelsteini" value="-"></td>
      </tr>
      <tr>
        
        <td>TINEL</td>
        <td><input type="radio" name="tineld" value="+"></td>
        <td><input type="radio" name="tineld" value="-"></td>
        <td><input type="radio" name="tineli" value="+"></td>
        <td><input type="radio" name="tineli" value="-"></td>
      </tr>

      <tr>
        
        <td>PHALEN</td>
        <td><input type="radio" name="phalemd" value="+"></td>
        <td><input type="radio" name="phalemd" value="-"></td>
        <td><input type="radio" name="phalemi" value="+"></td>
        <td><input type="radio" name="phalemi" value="-"></td>
      </tr>


    </tbody>
  </table>




</div>
<br><br>







<div class="snpan12"></div>
<div class="span6">
  <table  class="table table-hover table-nomargin table-bordered">
    <thead>
      <tr>
        <th></th>
        <th colspan="2">DEDOS MANOS</th>
        <th colspan="2">MUÑECA</th>
        <th colspan="2">ANTEBRAZO</th>
        <th colspan="2">CODOS</th>
        <th colspan="2">BRAZO</th>
        <th colspan="2">HOMBROS</th>

      </tr>
    </thead>
    <tbody>
      <tr>
        <td>INSPECCION</td>
        <td>Normal  <input type="radio" name="dedosmanosi"  value="normal" checked></td>
        <td>Anormal <input type="radio" name="dedosmanosi"  value="anormal"></td>
        <td>Normal  <input type="radio" name="munecai"      value="normal" checked></td>
        <td>Anormal <input type="radio" name="munecai"      value="anormal" ></td>
        <td>Normal  <input type="radio" name="antebrazoi"   value="normal" checked></td>
        <td>Anormal <input type="radio" name="antebrazoi"   value="anormal" ></td>
        <td>Normal  <input type="radio" name="codosi"       value="normal" checked></td>
        <td>Anormal <input type="radio" name="codosi"       value="anormal" ></td>
        <td>Normal  <input type="radio" name="brazoi"       value="anormal"  checked></td>
        <td>Anormal <input type="radio" name="brazoi"       value="anormal" ></td>
        <td>Normal  <input type="radio" name="hombrosi"     value="normal" checked></td>
        <td>Anormal <input type="radio" name="hombrosi"     value="anormal" ></td>
      </tr>
      <tr>
        <td>PALPACION</td>
        <td>Normal  <input type="radio" name="dedosmanosp"  value="normal" checked></td>
        <td>Anormal <input type="radio" name="dedosmanosp"  value="anormal"></td>
        <td>Normal  <input type="radio" name="munecap"      value="normal" checked></td>
        <td>Anormal <input type="radio" name="munecap"      value="anormal" ></td>
        <td>Normal  <input type="radio" name="antebrazop"   value="normal" checked></td>
        <td>Anormal <input type="radio" name="antebrazop"   value="anormal" ></td>
        <td>Normal  <input type="radio" name="codosp"       value="normal" checked></td>
        <td>Anormal <input type="radio" name="codosp"       value="anormal" ></td>
        <td>Normal  <input type="radio" name="brazop"       value="anormal" checked></td>
        <td>Anormal <input type="radio" name="brazop"       value="anormal" ></td>
        <td>Normal  <input type="radio" name="hombrosp"     value="normal" checked></td>
        <td>Anormal <input type="radio" name="hombrosp"     value="anormal" ></td>
      </tr>
        <td>MOVILIDAD</td>
        <td>Normal  <input type="radio" name="dedosmanosm"  value="normal" checked></td>
        <td>Anormal <input type="radio" name="dedosmanosm"  value="anormal"></td>
        <td>Normal  <input type="radio" name="munecam"      value="normal" checked></td>
        <td>Anormal <input type="radio" name="munecam"      value="anormal" ></td>
        <td>Normal  <input type="radio" name="antebrazom"   value="normal" checked></td>
        <td>Anormal <input type="radio" name="antebrazom"   value="anormal" ></td>
        <td>Normal  <input type="radio" name="codosm"       value="normal" checked></td>
        <td>Anormal <input type="radio" name="codosm"       value="anormal" ></td>
        <td>Normal  <input type="radio" name="brazom"       value="normal" checked></td>
        <td>Anormal <input type="radio" name="brazom"       value="anormal" ></td>
        <td>Normal  <input type="radio" name="hombrosm"     value="normal" checked></td>
        <td>Anormal <input type="radio" name="hombrosm"     value="anormal" ></td>
 
      </tr>
    </tbody>
  </table>


</div>





<div class="pan12"></div>
<div class="span6">
  <table  class="table table-hover table-nomargin table-bordered">
    <tbody>
      <tr>
        <td>TEST DE WELL</td>
        <td>I.    <input type="radio" name="testdewell" value="I"></td>
        <td>II.   <input type="radio" name="testdewell" value="II"></td>
        <td>III.  <input type="radio" name="testdewell" value="III"></td>
        <td>IV    <input type="radio" name="testdewell" value="IV"></td>
      </tr>
      <tr>
        <td>TEST DE  SHOBER</td>
        <td colspan="4"><input name="testdeshober" type="text"></td>
      </tr>
      <tr>
        <td rowspan="4">TEST NEUROLÓGICO</td>
      </tr>
      <tr>
        <td colspan="2">LASSEGUE DERECHO</td>
        <td colspan="2">LASSEGUE IZQUIERDO</td>
      </tr>
      <tr>
        <td>N</td>
        <td>A</td>
        <td>N</td>
        <td>A</td>
      </tr>
      <tr>
        <td><input type="radio" name="lassegued" value="n" checked></td>
        <td><input type="radio" name="lassegued" value="a"></td>
        <td><input type="radio" name="lasseguei" value="n" checked></td>
        <td><input type="radio" name="lasseguei" value="a"></td>

      </tr>
    </tbody>
  </table>
</div>
          