

  

        <div class="span12">
         
          <div class="control-group">
            <label for="textfield" class="control-label">Cargo actual</label>
            <div class="controls">
              <input type="text" name="cargoactual" id="cargoactual">
            </div>
          </div>
        </div>


         <div class="span12">
         
          <div class="control-group">
            <label for="textfield" class="control-label">Horario laboral (Hs)</label>
            <div class="controls">
              <input type="text" name="horaciolaboral" id="horaciolaboral">
            </div>
          </div>
        </div>


        <div class="span12">
         
          <div class="control-group">
            <label for="textfield" class="control-label">Turno</label>
            <div class="controls">
              <select name="turno" id="turno">
                <option>Diurno</option>
                <option>Nocturno</option>
                <option>Rotativo</option>
                  
              </select>
            </div>
          </div>
        </div>


        <div class="span12">
         
          <div class="control-group">
            <label for="textfield" class="control-label">Funciones</label>
            <div class="controls">
             <input type="text" name="funciones" id="funciones">
            </div>
          </div>
        </div>

        <div class="span12">
         
          <div class="control-group">
            <label for="textfield" class="control-label">Antiguedad</label>
            <div class="controls">
             <input type="text" name="antiguedad" id="antiguedad">
            </div>
          </div>
        </div>


