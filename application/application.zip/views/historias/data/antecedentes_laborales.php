

<div class="span12">
 
  <div class="control-group">
    <label for="textfield" class="control-label">Empresa</label>
    <div class="controls">
     <input type="text"  value="niega"name="empresaantecedente" id="empresaantecedente">
     <input type="text"  value="niega"name="empresaantecedente1" id="empresaantecedente1">
    </div>
  </div>
</div>

<div class="span12">
 
  <div class="control-group">
    <label for="textfield" class="control-label">Cargo</label>
    <div class="controls">
     <input type="text"  value="niega"name="cargoanttecedente" id="cargoanttecedente">
     <input type="text"  value="niega"name="cargoanttecedente1" id="cargoanttecedente1">
    </div>
  </div>
</div>

<div class="span12">
 
  <div class="control-group">
    <label for="textfield" class="control-label">Tiempo</label>
    <div class="controls">
     <input type="text"  value="niega"name="tiempoantecedente" id="tiempoantecedente">
     <input type="text"  value="niega"name="tiempoantecedente1" id="tiempoantecedente1">
    </div>
  </div>
</div>


<div class="span12">
 
  <div class="control-group">
    <label for="textfield" class="control-label">Incapacidad</label>
    <div class="controls">
     <input type="text"  value="niega"name="incapacidadantecedente" id="incapacidadantecedente">
     <input type="text"  value="niega"name="incapacidadantecedente1" id="incapacidad1">
    </div>
  </div>
</div>


<div class="span12">
 
  <div class="control-group">
    <label for="textfield" class="control-label">Riesgos</label>
    <div class="controls">
     <input type="text"  value="niega"name="riesgosantecdentes" id="riesgosantecdentes">
     <input type="text"  value="niega"name="riesgosantecdentes1" id="riesgosantecdentes1">
    </div>
  </div>
</div>
