<?php 
if($empresa!="no data"){
	echo json_encode($empresa);	
}else{
	print("no");	
}

 ?>