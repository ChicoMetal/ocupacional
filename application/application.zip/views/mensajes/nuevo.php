


<div class="span12">

	<form action="nuevo_submit" method="post" >
		<input type="hidden" name="de" value="">
		<div class="span12">
			<input type="text" name="para" placeholder="Para" value="">
		
		</div>
		<div class="span12">
			
			<input type="text" name="asunto" placeholder="Asunto" value="">
		</div>
		<div class="span12">
			<textarea name="mensaje" placeholder="Mensaje" cols="50" rows="5"></textarea>
		</div>
		<div class="span12">
			<input type="button" name="Enviar" value="Enviar">
		</div>
	</form>
		
</div>
