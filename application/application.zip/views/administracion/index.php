<style type="text/css">
.fondo{
	height: 60px;
	display: block;
	text-align: center; 
}
</style>
<div class="container">
<div class="row-fluid">
	<div class="span12">
		<div class="box">
			<div class="actions">
				<div class="fondo">
					<img src="<?php echo base_url() ?>img/cabecera1.png" alt="">

				</div>
			</div>
			<div class="box-content">
				
					<ul class="gallery">

						<li>
							<div class="box">
								<div class="box-title">
									Pacientes
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/pacientes">
										<img src="<?php echo base_url() ?>img/system/users.png" alt="">
									</a>
								</div>
							</div>
						
						</li>
					

						<li>
							<div class="box">
								<div class="box-title">
									Orden de atención
								</div>
								<div class="box-content">

									<a href="<?php echo base_url() ?>index.php/pacientes/orden">
										<img src="<?php echo base_url() ?>img/system/orden.png" alt="">
									</a>

								</div>
							</div>
						
						</li>
						
						<li>
							<div class="box">
								<div class="box-title">
									Listar Ordenes
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/ordenes/buscar_ordenes_pendientes">
										<img src="<?php echo base_url() ?>img/system/listar.png" alt="">
									</a>

								</div>
							</div>
						
						</li>
					
						<li>
							<div class="box">
								<div class="box-title">
									Certificados
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/pacientes/buscar_certificados">
										<img src="<?php echo base_url() ?>img/system/certificado.png" alt="">
									</a>

								</div>
							</div>
						
						</li>

						<li>
							<div class="box">
								<div class="box-title">
									Empresas
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/empresas">
										<img src="<?php echo base_url() ?>img/system/empresas.png" alt="">
									</a>

								</div>
							</div>
						
						</li>
							<li>
							<div class="box">
								<div class="box-title">
									Contratar actividades
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/empresas/contratar">
										<img src="<?php echo base_url() ?>img/system/contrato.png" alt="">
									</a>

								</div>
							</div>
						
					
					
					
						<li>
							<div class="box">
								<div class="box-title">
									Facturar 
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/reportes/facturacion">
										<img src="<?php echo base_url() ?>img/system/bill.png" alt="">
									</a>

								</div>
							</div>
						
						</li>
					
						<li>
							<div class="box">
								<div class="box-title">
									Proveedores 
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/proveedores">
										<img src="<?php echo base_url() ?>img/system/proveedores.png" alt="">
									</a>

								</div>
							</div>
						
						</li>
					<li>
							<div class="box">
								<div class="box-title">
									Mostrar Historias 
								</div>
								<div class="box-content">
									<a href="<?php echo base_url() ?>index.php/historias/mostrar_historias">
										<img src="<?php echo base_url() ?>img/system/historias.png" alt="">
									</a>

								</div>
							</div>
						
						</li>
					



					</ul>	


				
			</div>
		</div>
	</div>
</div>	
</div>