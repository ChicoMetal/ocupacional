<?php 
if($proveedor!="no data"){
	echo json_encode($proveedor);	
}else{
	print("no");	
}

 ?>