<div>
<img src="<?php echo base_url() ?>img/loader/<?php echo $gif ?>.gif">
</div>
